# Instagram Username Diagnostic V2

This is a conservative diagnostic tool, **not** an Instagram availability oracle. Instagram has no general public endpoint guaranteeing that a candidate username can be claimed. HTTP 404 means only that a profile wasn't found through that request; HTTP 200 may be a login page. Neither confirms registration availability.

## Install in your existing GitHub repository

1. Upload `checker_v2.py` to the repository root (alongside your existing `usernames.txt`).
2. Create `.github/workflows/username-diagnostic-v2.yml` using the supplied file contents. You can do this on GitHub via **Add file → Create new file**, entering the entire path.
3. Edit `usernames.txt` so its first five lines include a few known taken accounts and your candidates, for example:

   ```
   instagram
   nike
   cristiano
   rysvsifn37
   jrcq
   ```

4. Commit, then open **Actions → Instagram username diagnostic V2 → Run workflow**.
5. Download the `diagnostic-v2-results` artifact and share `results.csv` for interpretation.

The script runs without dependencies other than Python 3.11. It checks at most 10 public pages, uses a delay of at least 5 seconds, and stops on HTTP 403 or 429. It does not use credentials, proxies, session cookies, or access-control bypasses.

## Offline generation

Generate a unique random sample of four-character usernames (letters and digits) without contacting Instagram:

```
python checker_v2.py generate --count 1000 --output candidates.txt
```

For actual claimability, use Instagram's own username-change or sign-up interface manually. Do not interpret CSV statuses as guarantees.
